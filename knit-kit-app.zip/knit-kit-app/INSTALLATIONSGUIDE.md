# 🧶 Strikkekit App — Installationsguide

## Hvad appen gør
- Trækker automatisk lager på garn-produkter når et kit sælges
- Gendanner lager ved annullering eller refundering
- Opdaterer kit-priser automatisk når garnpriser ændres

---

## Trin 1 — Opret en Shopify App

1. Gå til **Shopify Admin** → **Apps** → **App and sales channel settings**
2. Klik **Develop apps** → **Create an app**
3. Giv den et navn, fx "Strikkekit Lagerstyring"
4. Under **Configuration** → **Admin API scopes**, vælg:
   - `read_products` + `write_products`
   - `read_inventory` + `write_inventory`
5. Klik **Install app**
6. Kopiér **Admin API access token** (vises kun én gang!)

---

## Trin 2 — Deploy på Railway

1. Gå til [railway.app](https://railway.app) og opret en gratis konto
2. Klik **New Project** → **Deploy from GitHub repo**
3. Upload eller connect denne mappe
4. Under **Variables**, tilføj disse miljøvariabler:

```
SHOPIFY_STORE        = minbutik.myshopify.com
SHOPIFY_ADMIN_TOKEN  = shpat_xxxx (fra trin 1)
SHOPIFY_WEBHOOK_SECRET = (se trin 3)
APP_URL              = https://din-app.railway.app
```

5. Railway giver dig automatisk en URL, fx `https://knit-kit-abc123.railway.app`

---

## Trin 3 — Find Webhook Secret

1. Gå til **Shopify Admin** → **Settings** → **Notifications**
2. Scroll ned til **Webhooks**
3. Kopiér **webhook signing secret**
4. Indsæt det som `SHOPIFY_WEBHOOK_SECRET` i Railway

---

## Trin 4 — Registrer Webhooks

1. Åbn din app: `https://din-app.railway.app`
2. Gå til fanen **OPSÆTNING**
3. Klik **Registrer webhooks i Shopify →**
4. Appen lytter nu automatisk på ordrer og prisændringer ✅

---

## Trin 5 — Opret kit-koblinger

1. Gå til fanen **KOBLINGER** i admin-panelet
2. For hvert kit:
   - Vælg kit-produktet og den specifikke variant (størrelse + farve)
   - Vælg det tilhørende garn-produkt og variant
   - Angiv antal nøgler
   - Klik **+ Tilføj kobling**
3. Gentag for alle garn i kittet

**Eksempel på et komplet kit:**
- Hygge Sweater M / Nordisk blå → Merino Wool DK / Ash Grey × 3 nøgler
- Hygge Sweater M / Nordisk blå → Alpaca Blend / Teal × 1 nøgle
- Hygge Sweater M / Nordisk blå → Cotton Linen / Ecru × 2 nøgler

---

## Det var det! 🎉

Fra nu af sker al lagerstyring automatisk i baggrunden.
Du kan følge med i **ORDRE-LOG** fanen.

---

## Spørgsmål?
Kontakt din udvikler eller åbn appen og tjek loggen for fejlmeldinger.
